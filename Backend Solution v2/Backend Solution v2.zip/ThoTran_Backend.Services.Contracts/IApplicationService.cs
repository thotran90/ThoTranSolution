﻿using $safeprojectname$.DataObjects.DataTransferObjects;

namespace $safeprojectname$.Services.Contracts
{
    public interface IApplicationService
    {
        AppInformationDto GetApp();
    }
}
