﻿namespace $safeprojectname$.DataObjects.Arguments
{
    public class LoginArgument
    {
        public string LoginId { get; set; }
        public string Password { get; set; }
    }
}
