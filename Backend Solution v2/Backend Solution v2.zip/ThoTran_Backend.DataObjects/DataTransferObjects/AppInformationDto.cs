﻿namespace $safeprojectname$.DataObjects.DataTransferObjects
{
    public class AppInformationDto
    {
        public int AppId { get; set; }
        public string Description { get; set; }
    }
}
