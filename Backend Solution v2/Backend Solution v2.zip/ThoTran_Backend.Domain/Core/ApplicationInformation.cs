﻿namespace $safeprojectname$.Domain.Core
{
    public class ApplicationInformation
    {
        public int AppId { get; set; }
        public string Description { get; set; }
    }
}
